import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  client: text("client"),
  status: text("status").notNull().default("active"), // active, paused, completed
  progress: integer("progress").notNull().default(0), // 0-100
  
  // Time tracking
  estimatedHours: decimal("estimated_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  actualHours: decimal("actual_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  
  // Budget tracking
  estimatedBudget: decimal("estimated_budget", { precision: 10, scale: 2 }).notNull().default("0"),
  actualBudget: decimal("actual_budget", { precision: 10, scale: 2 }).notNull().default("0"),
  
  // Resource tracking
  estimatedDevDays: integer("estimated_dev_days").notNull().default(0),
  actualDevDays: integer("actual_dev_days").notNull().default(0),
  estimatedDesignHours: decimal("estimated_design_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  actualDesignHours: decimal("actual_design_hours", { precision: 10, scale: 2 }).notNull().default("0"),
  
  // Dates
  dueDate: timestamp("due_date"),
  completedDate: timestamp("completed_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  message: text("message").notNull(),
  response: text("response").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateProjectSchema = insertProjectSchema.partial();

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type UpdateProject = z.infer<typeof updateProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Computed types for frontend
export type ProjectWithMargins = Project & {
  timeMargin: number;
  budgetMargin: number;
  resourceMargin: number;
};
