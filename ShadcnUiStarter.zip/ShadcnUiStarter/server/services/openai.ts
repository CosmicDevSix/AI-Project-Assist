import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-openai-api-key-here" 
});

export async function getAIResponse(userMessage: string, projectContext?: string): Promise<string> {
  try {
    const systemPrompt = `You are an AI assistant specialized in project management for developers and freelancers. You help users understand their project performance, margins, and provide actionable insights.

Key capabilities:
- Analyze project metrics (time, budget, resource margins)
- Provide suggestions for improving project efficiency
- Explain project status and performance trends
- Offer guidance on project management best practices
- Help with project planning and resource allocation

Always be concise, helpful, and focus on actionable advice. If you don't have enough context, ask clarifying questions.`;

    const contextualPrompt = projectContext 
      ? `Here's the current project context:\n\n${projectContext}\n\nUser question: ${userMessage}`
      : `User question: ${userMessage}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: contextualPrompt }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    const aiResponse = response.choices[0].message.content;
    
    if (!aiResponse) {
      throw new Error("No response generated from OpenAI");
    }

    return aiResponse;
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Provide helpful error messages based on the error type
    if (error instanceof Error) {
      if (error.message.includes("API key")) {
        return "I'm sorry, but I'm having trouble connecting to my AI services. Please check that the OpenAI API key is properly configured.";
      }
      
      if (error.message.includes("quota") || error.message.includes("billing")) {
        return "I'm currently unavailable due to API usage limits. Please try again later or contact support.";
      }
      
      if (error.message.includes("rate limit")) {
        return "I'm receiving too many requests right now. Please wait a moment and try again.";
      }
    }
    
    // Generic fallback response
    return "I'm sorry, I'm having trouble processing your request right now. Please try again in a moment. If the problem persists, you can still manage your projects using the dashboard features.";
  }
}

// Helper function to generate project insights
export async function generateProjectInsights(projects: any[]): Promise<string> {
  try {
    const projectSummary = projects.map(p => ({
      name: p.name,
      status: p.status,
      progress: p.progress,
      timeMargin: p.timeMargin,
      budgetMargin: p.budgetMargin,
    }));

    const prompt = `Analyze these project metrics and provide a brief summary with key insights and recommendations:

${JSON.stringify(projectSummary, null, 2)}

Focus on:
1. Overall portfolio health
2. Projects that need attention
3. Trends in margins and performance
4. Actionable recommendations

Keep the response concise (under 200 words) and actionable.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "user", content: prompt }
      ],
      max_tokens: 300,
      temperature: 0.5,
    });

    return response.choices[0].message.content || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Error generating project insights:", error);
    return "Project insights are temporarily unavailable.";
  }
}
