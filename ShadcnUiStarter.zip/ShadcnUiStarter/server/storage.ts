import { projects, chatMessages, type Project, type InsertProject, type UpdateProject, type ChatMessage, type InsertChatMessage } from "@shared/schema";

export interface IStorage {
  // Project CRUD
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: UpdateProject): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  // Chat messages
  getChatMessages(projectId?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private projects: Map<number, Project>;
  private chatMessages: Map<number, ChatMessage>;
  private currentProjectId: number;
  private currentChatId: number;

  constructor() {
    this.projects = new Map();
    this.chatMessages = new Map();
    this.currentProjectId = 1;
    this.currentChatId = 1;
    
    // Initialize with some sample data for development
    this.initializeData();
  }

  private initializeData() {
    const now = new Date();
    const sampleProjects: Project[] = [
      {
        id: 1,
        name: "E-commerce Platform",
        description: "A comprehensive e-commerce platform with advanced features including user authentication, payment processing, inventory management, and analytics dashboard.",
        client: "TechCorp Inc.",
        status: "active",
        progress: 65,
        estimatedHours: "120.00",
        actualHours: "114.00",
        estimatedBudget: "8000.00",
        actualBudget: "8648.00",
        estimatedDevDays: 16,
        actualDevDays: 15,
        estimatedDesignHours: "20.00",
        actualDesignHours: "24.00",
        dueDate: new Date("2024-12-15"),
        completedDate: null,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 2,
        name: "Mobile App Redesign",
        description: "Complete UI/UX redesign of mobile application with modern design patterns and improved user experience.",
        client: "StartupXYZ",
        status: "paused",
        progress: 30,
        estimatedHours: "80.00",
        actualHours: "82.00",
        estimatedBudget: "5000.00",
        actualBudget: "4385.00",
        estimatedDevDays: 10,
        actualDevDays: 8,
        estimatedDesignHours: "40.00",
        actualDesignHours: "35.00",
        dueDate: new Date("2025-01-20"),
        completedDate: null,
        createdAt: now,
        updatedAt: now,
      },
      {
        id: 3,
        name: "API Development",
        description: "RESTful API development with comprehensive documentation and testing suite.",
        client: "HealthTech Solutions",
        status: "completed",
        progress: 100,
        estimatedHours: "60.00",
        actualHours: "51.00",
        estimatedBudget: "4500.00",
        actualBudget: "4100.00",
        estimatedDevDays: 8,
        actualDevDays: 7,
        estimatedDesignHours: "5.00",
        actualDesignHours: "3.00",
        dueDate: new Date("2024-11-30"),
        completedDate: new Date("2024-11-28"),
        createdAt: now,
        updatedAt: now,
      },
    ];

    sampleProjects.forEach(project => {
      this.projects.set(project.id, project);
      this.currentProjectId = Math.max(this.currentProjectId, project.id + 1);
    });
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const now = new Date();
    const project: Project = {
      id,
      name: insertProject.name,
      description: insertProject.description ?? null,
      client: insertProject.client ?? null,
      status: insertProject.status ?? "active",
      progress: insertProject.progress ?? 0,
      estimatedHours: insertProject.estimatedHours ?? "0",
      actualHours: insertProject.actualHours ?? "0",
      estimatedBudget: insertProject.estimatedBudget ?? "0",
      actualBudget: insertProject.actualBudget ?? "0",
      estimatedDevDays: insertProject.estimatedDevDays ?? 0,
      actualDevDays: insertProject.actualDevDays ?? 0,
      estimatedDesignHours: insertProject.estimatedDesignHours ?? "0",
      actualDesignHours: insertProject.actualDesignHours ?? "0",
      dueDate: insertProject.dueDate ?? null,
      completedDate: insertProject.completedDate ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateProject: UpdateProject): Promise<Project | undefined> {
    const existing = this.projects.get(id);
    if (!existing) return undefined;

    const updated: Project = {
      ...existing,
      ...updateProject,
      updatedAt: new Date(),
    };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getChatMessages(projectId?: number): Promise<ChatMessage[]> {
    const messages = Array.from(this.chatMessages.values());
    if (projectId) {
      return messages.filter(msg => msg.projectId === projectId);
    }
    return messages.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatId++;
    const message: ChatMessage = {
      id,
      projectId: insertMessage.projectId ?? null,
      message: insertMessage.message,
      response: insertMessage.response,
      createdAt: new Date(),
    };
    this.chatMessages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
