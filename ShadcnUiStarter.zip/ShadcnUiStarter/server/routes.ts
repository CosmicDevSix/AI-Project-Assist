import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, updateProjectSchema, insertChatMessageSchema } from "@shared/schema";
import { getAIResponse } from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      
      // Calculate margins for each project
      const projectsWithMargins = projects.map(project => {
        const timeMargin = project.estimatedHours !== "0" 
          ? ((parseFloat(project.estimatedHours) - parseFloat(project.actualHours)) / parseFloat(project.estimatedHours)) * 100
          : 0;
        
        const budgetMargin = project.estimatedBudget !== "0"
          ? ((parseFloat(project.estimatedBudget) - parseFloat(project.actualBudget)) / parseFloat(project.estimatedBudget)) * 100
          : 0;
        
        const resourceMargin = project.estimatedDevDays > 0 || parseFloat(project.estimatedDesignHours) > 0
          ? (((project.estimatedDevDays - project.actualDevDays) + (parseFloat(project.estimatedDesignHours) - parseFloat(project.actualDesignHours)) / 8) / 
             (project.estimatedDevDays + parseFloat(project.estimatedDesignHours) / 8)) * 100
          : 0;

        return {
          ...project,
          timeMargin: Math.round(timeMargin * 10) / 10,
          budgetMargin: Math.round(budgetMargin * 10) / 10,
          resourceMargin: Math.round(resourceMargin * 10) / 10,
        };
      });

      res.json(projectsWithMargins);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateProjectSchema.parse(req.body);
      const project = await storage.updateProject(id, validatedData);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteProject(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Chat routes
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const messages = await storage.getChatMessages(projectId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat/message", async (req, res) => {
    try {
      const { message, projectId } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get project context if projectId is provided
      let projectContext = "";
      if (projectId) {
        const project = await storage.getProject(projectId);
        if (project) {
          const timeMargin = project.estimatedHours !== "0" 
            ? ((parseFloat(project.estimatedHours) - parseFloat(project.actualHours)) / parseFloat(project.estimatedHours)) * 100
            : 0;
          
          const budgetMargin = project.estimatedBudget !== "0"
            ? ((parseFloat(project.estimatedBudget) - parseFloat(project.actualBudget)) / parseFloat(project.estimatedBudget)) * 100
            : 0;

          projectContext = `Project: ${project.name}
Client: ${project.client || "No client specified"}
Status: ${project.status}
Progress: ${project.progress}%
Time Margin: ${timeMargin.toFixed(1)}%
Budget Margin: ${budgetMargin.toFixed(1)}%
Estimated Hours: ${project.estimatedHours}
Actual Hours: ${project.actualHours}
Estimated Budget: $${project.estimatedBudget}
Actual Budget: $${project.actualBudget}
Due Date: ${project.dueDate ? project.dueDate.toISOString().split('T')[0] : "Not set"}
Description: ${project.description || "No description"}`;
        }
      }

      // Get AI response
      const aiResponse = await getAIResponse(message, projectContext);
      
      // Save the conversation
      const chatMessage = await storage.createChatMessage({
        projectId: projectId || null,
        message,
        response: aiResponse,
      });

      res.json({ response: aiResponse, messageId: chatMessage.id });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // Stats endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      
      const activeProjects = projects.filter(p => p.status === "active").length;
      const totalRevenue = projects.reduce((sum, p) => sum + parseFloat(p.actualBudget), 0);
      const totalHours = projects.reduce((sum, p) => sum + parseFloat(p.actualHours), 0);
      
      const margins = projects.map(project => {
        const timeMargin = project.estimatedHours !== "0" 
          ? ((parseFloat(project.estimatedHours) - parseFloat(project.actualHours)) / parseFloat(project.estimatedHours)) * 100
          : 0;
        
        const budgetMargin = project.estimatedBudget !== "0"
          ? ((parseFloat(project.estimatedBudget) - parseFloat(project.actualBudget)) / parseFloat(project.estimatedBudget)) * 100
          : 0;

        return (timeMargin + budgetMargin) / 2;
      });
      
      const avgMargin = margins.length > 0 
        ? margins.reduce((sum, margin) => sum + margin, 0) / margins.length 
        : 0;

      res.json({
        activeProjects,
        totalRevenue,
        totalHours,
        avgMargin: Math.round(avgMargin * 10) / 10,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
