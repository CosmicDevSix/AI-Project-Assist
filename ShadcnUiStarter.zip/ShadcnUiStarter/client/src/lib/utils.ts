import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatDate(date: Date | string | null): string {
  if (!date) return "Not set";
  const d = new Date(date);
  return d.toLocaleDateString("en-US", { 
    month: "short", 
    day: "numeric", 
    year: "numeric" 
  });
}

export function calculateMargin(estimated: number, actual: number): number {
  if (estimated === 0) return 0;
  return ((estimated - actual) / estimated) * 100;
}

export function getMarginColor(margin: number): string {
  if (margin > 5) return "text-green-600";
  if (margin < -5) return "text-red-600";
  return "text-yellow-600";
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "active":
      return "bg-green-100 text-green-800 hover:bg-green-200";
    case "paused":
      return "bg-yellow-100 text-yellow-800 hover:bg-yellow-200";
    case "completed":
      return "bg-slate-100 text-slate-600 hover:bg-slate-200";
    default:
      return "bg-slate-100 text-slate-600 hover:bg-slate-200";
  }
}
