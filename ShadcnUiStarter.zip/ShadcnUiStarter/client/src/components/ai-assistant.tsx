import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ChatMessage {
  id: number;
  message: string;
  response: string;
  createdAt: string;
}

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const { data: messages = [] } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
    enabled: isOpen,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest("POST", "/api/chat/message", {
        message: messageText,
      });
      return response.json();
    },
    onSuccess: () => {
      setMessage("");
      // Refetch messages to show the new conversation
      window.location.reload(); // Simple refresh for demo
    },
    onError: () => {
      toast({
        title: "Failed to send message",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendMessageMutation.mutate(message);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button 
            size="lg"
            className="w-14 h-14 rounded-full shadow-lg bg-blue-500 hover:bg-blue-600"
          >
            <MessageCircle size={20} />
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          side="top" 
          align="end" 
          className="w-80 p-0 shadow-2xl"
          sideOffset={10}
        >
          <div className="bg-blue-500 p-4 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar className="w-8 h-8 bg-white/20">
                  <AvatarFallback className="bg-white/20 text-white">
                    <Bot size={16} />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-semibold">AI Assistant</h4>
                  <p className="text-xs opacity-90">Online</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20 h-8 w-8"
                onClick={() => setIsOpen(false)}
              >
                <X size={16} />
              </Button>
            </div>
          </div>
          
          <ScrollArea className="h-64 p-4">
            <div className="space-y-4">
              {messages.length === 0 ? (
                <div className="flex items-start space-x-3">
                  <Avatar className="w-6 h-6 bg-blue-500 flex-shrink-0">
                    <AvatarFallback className="bg-blue-500 text-white">
                      <Bot size={12} />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-slate-100 p-3 rounded-lg flex-1">
                    <p className="text-sm text-slate-900">
                      Hi! I'm here to help with your projects. What would you like to know?
                    </p>
                  </div>
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className="space-y-3">
                    {/* User message */}
                    <div className="flex items-start space-x-3 justify-end">
                      <div className="bg-blue-500 p-3 rounded-lg text-white max-w-xs">
                        <p className="text-sm">{msg.message}</p>
                      </div>
                      <Avatar className="w-6 h-6 bg-slate-300 flex-shrink-0">
                        <AvatarFallback className="bg-slate-300 text-white">
                          <User size={12} />
                        </AvatarFallback>
                      </Avatar>
                    </div>
                    
                    {/* AI response */}
                    <div className="flex items-start space-x-3">
                      <Avatar className="w-6 h-6 bg-blue-500 flex-shrink-0">
                        <AvatarFallback className="bg-blue-500 text-white">
                          <Bot size={12} />
                        </AvatarFallback>
                      </Avatar>
                      <div className="bg-slate-100 p-3 rounded-lg flex-1">
                        <p className="text-sm text-slate-900">{msg.response}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
              
              {sendMessageMutation.isPending && (
                <div className="flex items-start space-x-3">
                  <Avatar className="w-6 h-6 bg-blue-500 flex-shrink-0">
                    <AvatarFallback className="bg-blue-500 text-white">
                      <Bot size={12} />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-slate-100 p-3 rounded-lg flex-1">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          
          <div className="p-4 border-t border-slate-200">
            <form onSubmit={handleSendMessage} className="flex space-x-2">
              <Input
                placeholder="Ask about your projects..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1"
                disabled={sendMessageMutation.isPending}
              />
              <Button 
                type="submit" 
                size="icon"
                disabled={sendMessageMutation.isPending || !message.trim()}
              >
                <Send size={16} />
              </Button>
            </form>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
