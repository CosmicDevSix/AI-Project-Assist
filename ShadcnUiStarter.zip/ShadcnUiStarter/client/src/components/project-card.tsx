import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { MoreVertical } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import type { ProjectWithMargins } from "@shared/schema";

interface ProjectCardProps {
  project: ProjectWithMargins;
  onEdit: () => void;
  onArchive: () => void;
}

export function ProjectCard({ project, onEdit, onArchive }: ProjectCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case "paused":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-200";
      case "completed":
        return "bg-slate-100 text-slate-600 hover:bg-slate-200";
      default:
        return "bg-slate-100 text-slate-600 hover:bg-slate-200";
    }
  };

  const getProgressColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-blue-500";
      case "paused":
        return "bg-yellow-500";
      case "completed":
        return "bg-green-500";
      default:
        return "bg-slate-400";
    }
  };

  const getMarginColor = (margin: number) => {
    if (margin > 5) return "text-green-600";
    if (margin < -5) return "text-red-600";
    return "text-yellow-600";
  };

  const formatMargin = (margin: number) => {
    const sign = margin >= 0 ? "+" : "";
    return `${sign}${margin.toFixed(1)}%`;
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "Not set";
    const d = new Date(date);
    return d.toLocaleDateString("en-US", { 
      month: "short", 
      day: "numeric", 
      year: "numeric" 
    });
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-900 mb-1">{project.name}</h3>
            <p className="text-sm text-slate-600">{project.client || "No client"}</p>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={getStatusColor(project.status)}>
              {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical size={16} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onEdit}>Edit</DropdownMenuItem>
                <DropdownMenuItem onClick={onArchive}>Archive</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <div className="space-y-3 mb-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">Progress</span>
            <span className="text-sm font-medium text-slate-900">{project.progress}%</span>
          </div>
          <div className="w-full">
            <Progress 
              value={project.progress} 
              className="h-2"
              indicatorClassName={getProgressColor(project.status)}
            />
          </div>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">Time Margin</span>
            <span className={`text-sm font-medium ${getMarginColor(project.timeMargin)}`}>
              {formatMargin(project.timeMargin)}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">Budget Margin</span>
            <span className={`text-sm font-medium ${getMarginColor(project.budgetMargin)}`}>
              {formatMargin(project.budgetMargin)}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">Due Date</span>
            <span className="text-sm font-medium text-slate-900">
              {formatDate(project.dueDate)}
            </span>
          </div>
        </div>

        <div className="flex space-x-2">
          <Button onClick={onEdit} className="flex-1">
            Edit
          </Button>
          <Button onClick={onArchive} variant="outline">
            Archive
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
