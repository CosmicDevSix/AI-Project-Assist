import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Brain, Bell, User, Plus, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { ProjectCard } from "@/components/project-card";
import { ProjectModal } from "@/components/project-modal";
import { AIAssistant } from "@/components/ai-assistant";
import { StatsOverview } from "@/components/stats-overview";
import type { ProjectWithMargins } from "@shared/schema";

export default function Dashboard() {
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<ProjectWithMargins | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("updated");

  const { data: allProjects = [], isLoading } = useQuery<ProjectWithMargins[]>({
    queryKey: ["/api/projects"],
  });

  // Filter and sort projects based on user selection
  const projects = useMemo(() => {
    let filtered = allProjects;

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter(project => project.status === statusFilter);
    }

    // Apply sorting
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name);
        case "progress":
          return b.progress - a.progress;
        case "timeMargin":
          return b.timeMargin - a.timeMargin;
        case "budgetMargin":
          return b.budgetMargin - a.budgetMargin;
        case "dueDate":
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case "updated":
        default:
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      }
    });

    return sorted;
  }, [allProjects, statusFilter, sortBy]);

  const handleEditProject = (project: ProjectWithMargins) => {
    setSelectedProject(project);
    setIsProjectModalOpen(true);
  };

  const handleNewProject = () => {
    setSelectedProject(null);
    setIsProjectModalOpen(true);
  };

  const closeModal = () => {
    setIsProjectModalOpen(false);
    setSelectedProject(null);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                <Brain className="text-white" size={16} />
              </div>
              <h1 className="text-xl font-bold text-slate-900">AI Project Assist</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="text-slate-600 hover:text-slate-900">
                <Bell size={18} />
                <span className="sr-only">Notifications</span>
              </Button>
              <Button variant="ghost" className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 px-3 py-2">
                <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <User className="text-white" size={12} />
                </div>
                <span className="text-sm font-medium text-slate-900">John Doe</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Project Dashboard</h2>
            <p className="text-slate-600 mt-1">
              Track your projects, margins, and get AI-powered assistance
              {!isLoading && (
                <span className="ml-2 text-sm">
                  • Showing {projects.length} of {allProjects.length} projects
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center space-x-3 mt-4 lg:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center space-x-2">
                  <Filter size={16} />
                  <span>Filter & Sort</span>
                  {(statusFilter !== "all" || sortBy !== "updated") && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-2 py-1.5 text-sm font-medium text-slate-600">Filter by Status</div>
                <DropdownMenuItem onClick={() => setStatusFilter("all")} className={statusFilter === "all" ? "bg-slate-100" : ""}>
                  All Projects
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("active")} className={statusFilter === "active" ? "bg-slate-100" : ""}>
                  Active Only
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("paused")} className={statusFilter === "paused" ? "bg-slate-100" : ""}>
                  Paused Only
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setStatusFilter("completed")} className={statusFilter === "completed" ? "bg-slate-100" : ""}>
                  Completed Only
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <div className="px-2 py-1.5 text-sm font-medium text-slate-600">Sort by</div>
                <DropdownMenuItem onClick={() => setSortBy("updated")} className={sortBy === "updated" ? "bg-slate-100" : ""}>
                  Recently Updated
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("name")} className={sortBy === "name" ? "bg-slate-100" : ""}>
                  Project Name
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("progress")} className={sortBy === "progress" ? "bg-slate-100" : ""}>
                  Progress
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("timeMargin")} className={sortBy === "timeMargin" ? "bg-slate-100" : ""}>
                  Time Margin
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("budgetMargin")} className={sortBy === "budgetMargin" ? "bg-slate-100" : ""}>
                  Budget Margin
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy("dueDate")} className={sortBy === "dueDate" ? "bg-slate-100" : ""}>
                  Due Date
                </DropdownMenuItem>
                {(statusFilter !== "all" || sortBy !== "updated") && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => {
                        setStatusFilter("all");
                        setSortBy("updated");
                      }}
                      className="text-slate-500"
                    >
                      Clear Filters
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={handleNewProject} className="flex items-center space-x-2">
              <Plus size={16} />
              <span>New Project</span>
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <StatsOverview />

        {/* Project Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="animate-pulse">
                  <div className="h-6 bg-slate-200 rounded mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded mb-4 w-2/3"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-slate-200 rounded"></div>
                    <div className="h-4 bg-slate-200 rounded"></div>
                    <div className="h-4 bg-slate-200 rounded"></div>
                  </div>
                </div>
              </div>
            ))
          ) : projects.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <div className="text-slate-400 mb-4">
                <Brain size={48} className="mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-2">No projects yet</h3>
              <p className="text-slate-600 mb-4">Get started by creating your first project</p>
              <Button onClick={handleNewProject}>
                <Plus size={16} className="mr-2" />
                Create Project
              </Button>
            </div>
          ) : (
            projects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onEdit={() => handleEditProject(project)}
                onArchive={() => {/* TODO: Implement archive */}}
              />
            ))
          )}
        </div>
      </main>

      {/* Floating AI Assistant */}
      <AIAssistant />

      {/* Project Modal */}
      <ProjectModal
        isOpen={isProjectModalOpen}
        onClose={closeModal}
        project={selectedProject}
      />
    </div>
  );
}
